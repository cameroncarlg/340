#include <iostream>
#include <cstdlib>
#include <chrono>
#include <time.h>
#include <cmath>
#include <iomanip>
#include "vector"
using namespace std;
using namespace std::chrono;

int main() {

    /*
     * description: create and populate the array
     */
    vector<int> list(10000000);
    for (int & i : list) {
        i = rand() % 100 + 1;;
    }

    /*
     * description: start comparisons with for-each loop, timed
     */
    int min = list[0];
    int max = list[1];
    auto start = high_resolution_clock::now();
    for (int i : list) {
        if (i < min) {
            min = i;
        }
        if (i > max) {
            max = i;
        }
    }
    auto end = high_resolution_clock::now();
    double diff = duration_cast<nanoseconds>(end - start).count();
    diff *= 1e-9;

    
    for (auto go : list) {
        cout << go << endl;
    }

    cout << endl;
    cout << "min: " << min << endl;
    cout << "max: " << max << endl;
    cout << "time: " << diff << setprecision(9) << endl;


    return 0;
}
